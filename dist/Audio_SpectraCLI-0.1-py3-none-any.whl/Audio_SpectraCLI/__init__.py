# __init__.py

from .main import audio_visualizer
